# Maltraña · sitio web (revisión 2)

Sitio estático en HTML5, CSS y JavaScript sobre **Bootstrap 5.3.3**. Mobile first.

## Cómo verlo

Abrir la carpeta con un servidor local (por ejemplo, la extensión *Live Server* de VS Code) y entrar a `index.html`.
Al cargar aparece el aviso de mayoría de edad; al responder "Sí" se guarda una cookie por 1 hora (`mlt_mayor_edad`).

## Estructura

```
index.html                 Inicio
raicillas-maltrana.html    Raicillas Maltraña (productos)
cocteleria.html            Experiencias · Coctelería
ruta-de-la-raicilla.html   Experiencias · Ruta de la Raicilla
catas.html                 Experiencias · Catas
raicilla.html              Raicilla
distribucion.html          Distribución
maltrana.html              Maltraña
contacto.html              Contacto
privacidad.html · cookies.html · consumo-responsable.html   Legales

tokens.css     Colores y tipografías de la marca (variables CSS)
style.css      Estilos propios; al inicio tiene un índice por secciones
main.js        Interacciones (pestañas/acordeón, menú de celular, carta de coctelería, pilares, relato del proceso)
age-gate.js    Aviso de mayoría de edad

assets/favicon   Íconos del sitio y manifest
assets/svg       Logo, ornamentos e ícono de agave
assets/img       Fotos por página, en AVIF y WebP
```

## Dependencias (CDN)

- Bootstrap 5.3.3 (CSS y `bootstrap.bundle.min.js`)
- Bootstrap Icons 1.11.3
- Google Fonts: Crimson Pro (títulos) y Barlow (texto)

## Convenciones

- Orden de carga: Bootstrap → íconos → fuentes → `tokens.css` → `style.css`.
- Primero se usan utilidades y componentes de Bootstrap; `style.css` solo cubre lo que Bootstrap no resuelve.
- Clases propias con prefijo `.mlt-` (nombres tipo bloque__elemento--variante).
- Breakpoints: menos de 768px = celular; desde 768px (md) = tablet y escritorio.
- El sitio usa el tema oscuro (`data-bs-theme="dark"` en `<html>`); las secciones claras llevan `data-bs-theme="light"`.
- Fotos con `<picture>`: AVIF primero y WebP como respaldo, siempre con `width` y `height`.
- Cada sección del HTML lleva un comentario que explica qué es y cómo se comporta.

## Contenido

- Los textos en *Lorem ipsum* y los enlaces con `href="#"` (WhatsApp, Google Maps, redes) se reemplazan cuando llegue el contenido final.
- La carta de coctelería no muestra precios.
